<?php
$this->breadcrumbs=array(
	'Gerenciar Usuários',
);

$this->menu=array(
	array('label'=>'Adicionar Usuário', 'url'=>array('create')),
	array('label'=>'Gerenciar Páginas', 'url'=>array('/pagina/admin')),
);
?>

<h1>Gerenciar Usuários</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'users-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'username',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
