<?php $this->beginContent('//layouts/main'); ?>
<div class="containger">
<div class="row">
		<?php echo $content; ?>
</div>
</div>
<?php $this->endContent(); ?>