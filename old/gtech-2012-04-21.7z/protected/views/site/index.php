<div class="view">
<?php echo Pagina::model()->findByPk(1)->conteudo;?>
</div>