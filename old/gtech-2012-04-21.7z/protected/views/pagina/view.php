<?php
 
$this->breadcrumbs=array(
	$model->titulo,
);
?>

<?php 
	Yii::app()->clientScript->registerScript('ready', "
	$(document).ready(function(){
		$('.view').show('fast');
	});
	
	");
?>

 <!--start intro-->

<div class="container">
<div class="row">


 <section id="intro">

      <hgroup>
<!--      <h1></h1>-->	
      <h2><?php echo CHtml::encode($model->titulo);?></h2>
      
      </hgroup>
   </section>
</div>
</div>
<!--end intro-->   


   <!--start columns-->

<div class="container">
<div class="row">	
		
<div class="holder_content">

<div class="fourcol">
   <section class="group1">
   <h3>About us</h3>
   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. 
   Vestibulum condimentum  facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy.</p>
   <a class="photo_hover3" href="#"><img src="images/picture1.jpg" width="240" height="214" alt="picture1"/></a>
   <a href="#"><span class="button">Read more</span></a>   
   </section>
 </div>
 
<div class="fourcol">
<section class="group1">
	<?php 
		echo $model->conteudo; 
		
			if(!Yii::app()->user->isGuest){
			echo "<hr>";
			echo CHtml::link("Editar", array("/pagina/update/" .$model->cod_pagina), array("class"=>"button"));
	}
	?>
</section>
</div>

<div class="fourcol last">
   <section class="group1">
   <h3>Latest news</h3>
   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. 
   Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy.   </p>
   <a class="photo_hover3" href="#"><img src="images/picture3.jpg" width="240" height="214" alt="picture1"/></a>
   <a href="#"><span class="button">Read more</span></a>   
    </section>
</div>

<div class="twelvecol last">
    <section class="group2">
    <h3>Latest article</h3>
   
   <article>
   <h4>10.04.2012  - Design to express </h4>
   Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. 
   Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy. Cras quis libero.     
   Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. 
   Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst. Nulla nonummy. Cras quis libero.
   Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. 
   Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst.
   Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec molestie. Sed aliquam sem ut arcu. Phasellus sollicitudin. 
   Vestibulum condimentum facilisis nulla. In hac habitasse platea dictumst.
   </article> 
   </section>
   </div>


</div> <!-- end holder -->

</div>
</div>
<!-- end colunms -->