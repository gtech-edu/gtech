	<h3><?php echo CHtml::link(CHtml::encode($data->titulo), array('view', 'id'=>$data->cod_pagina)); ?></h3>
	<br />
 

