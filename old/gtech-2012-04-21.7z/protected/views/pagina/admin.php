<?php
$this->breadcrumbs=array(
	'Paginas'=>array('index'),
	'Gerenciar',
);

$this->menu=array(
	array('label'=>'Adicionar Página', 'url'=>array('create')),
	array('label'=>'Gerenciar Usuários', 'url'=>array('users/admin')),
);


?>

<h1>Gerenciar Páginas</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'pagina-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'titulo',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
