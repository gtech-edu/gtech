<?php

class HomeController extends Controller
{
	public function actionIndex()
	{	
		$paginas = Pagina::model()->findAll();
		//TODO
		$this->render('/site/view', array('group1'=>Pagina::model()->findByPk(1),
										  'group2'=>Pagina::model()->findByPk(3),
										  'group3'=>Pagina::model()->findByPk(8)));
	}

	// Uncomment the following methods and override them if needed
	/*
	public function filters()
	{
		// return the filter configuration for this controller, e.g.:
		return array(
			'inlineFilterName',
			array(
				'class'=>'path.to.FilterClass',
				'propertyName'=>'propertyValue',
			),
		);
	}

	public function actions()
	{
		// return external action classes, e.g.:
		return array(
			'action1'=>'path.to.ActionClass',
			'action2'=>array(
				'class'=>'path.to.AnotherActionClass',
				'propertyName'=>'propertyValue',
			),
		);
	}
	*/
}